-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(1650010)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1650011,0,"aeb35777de6823dd579753720a7ef2d1e1e4908fb2136a76d3325da51f7b3e0a")
setManifestid(1650011,"4534034758560317760")