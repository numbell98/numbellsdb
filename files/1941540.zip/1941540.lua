-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(1941540)
addappid(1941541,0,"47c1ea957b9ecc8662a117fa6b19eea01ed30ef06478a364110fe40afa4e9f0e")
setManifestid(1941541,"7389755233066346624")
addappid(3262000)
addappid(3269260)
addappid(3269270)
addappid(3269280)