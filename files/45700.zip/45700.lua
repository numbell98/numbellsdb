-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(45700)
addappid(45701,0,"1302efa5f93914449d8d4b7a25c7a5db86023e4186981e2237b1766f9d255b13")
setManifestid(45701,"4422185108218732385")