-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(70)
addappid(1, 1, "b465d45ab2a7c396f7d1c08a6644e68529ec86b14da77e18588abbbcd2412060")
setManifestid(1, "2667117727132184734", 0)
addappid(2, 1, "fd681c065529f5ee95e920321a780a9290f8f31ef51c232ccb3e98d27e132ebc")
setManifestid(2, "724247850320422500", 0)
addappid(8, 1, "20af1043db56d6408ddd965580e1269005b6e04f81c3676d155174f73099da95")
setManifestid(8, "1360709870205537514", 0)
addappid(9, 1, "68c92cf2532cdc6e0b7a9d2783b473b6d16bac72218badf68d7be9b033076096")
setManifestid(9, "1083345737969856561", 0)
addappid(71, 1, "71d9ddf78d068fed9320d6fcf7733b62e6957de71a5a14bfa9620401e97d3829")
setManifestid(71, "3982364535202188842", 0)
addappid(74, 1, "49d573f303205df2316749a6ede6725b74651fae3e845494b88ac3d0022a2857")
setManifestid(74, "6929797608257779911", 0)
addappid(75, 1, "1339202607b6485322859fc1f045c6790bbc470a2d3bb8158aa94b06da31f9bb")
setManifestid(75, "6599379689843151742", 0)