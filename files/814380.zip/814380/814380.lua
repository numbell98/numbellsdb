-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(814380)
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228990)
setManifestid(228990,"5087715316087945828")
addappid(814381,0,"84db6d0cd0648c885d471541b83416e460f07ad6b71e1b86b2fa26926514d874")
setManifestid(814381,"7598923580425802222")
addappid(814382,0,"742e0660742d90e8f827db3e00bcbf594970e97e76f8fb90ec74a54562ef5502")
setManifestid(814382,"8495754623934990551")
addappid(814383,0,"3f8022efca09175e6bef77385ece0b5693e94d829d50baab66f9e249b996992b")
setManifestid(814383,"1996592192490629382")
addappid(814385,0,"8689daaad42496510eb7b2fc6f6de095af54aae85e481998eb4746d2fad6b9af")
setManifestid(814385,"1613271962634429538")
addappid(1039230,0,"fdf0783fc1f1f3ee832c2912beffe0982e4f6d2abb1b63c8266fade7ad7f4493")
setManifestid(1039230,"1077830899885356469")