-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(3438800)
addappid(3438801, 1, "d7c3577cfbad3d5beb7a8dc46c1305693679a43e287b97f73599ea233100113b")
setManifestid(3438801, "2001665273213678949", 0)
