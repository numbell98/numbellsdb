-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(2686630)
addappid(3955500)
addappid(2686631,0,"bb444f58dde496878d4698ea44922d7072a6c466c8b4ef9416321f4efe9ed7fa")
setManifestid(2686631,"3269598522043953657")