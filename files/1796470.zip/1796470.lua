-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(1796470)
addappid(1796471, 1, "1be44ffc3d55a3bfef475a9ca61508d531a7ff622c0d1ae83629e6b393fa0932")
setManifestid(1796471, "2677617096513539400", 0)
addappid(3587100)
addappid(3587101, 1, "2c0b7404519eef3fad96505eee8ef9dfd335c1c26ede4ca40ffa3ab7d0f0617e")
setManifestid(3587101, "5671927963192264899", 0)
addappid(3587102, 1, "3480d60cd7ed2b25daa568920bcea90ab3b655070f8d80eae64afd9a66abb8a0")
setManifestid(3587102, "2925846499593192497", 0)
