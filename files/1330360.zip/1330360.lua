-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(1330360)
addappid(1330361, 1, "485332bfd73e2b523a7e434d7a2b311138837fe2cffd76098fde839c90a8369e")
addappid(3969160)
addappid(3969160, 1, "5228ba921a89718f8b0b9e3f898600c57d1914c26b1057b2fb7e9ed6cf982ade")
