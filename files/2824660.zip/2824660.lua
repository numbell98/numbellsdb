-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(2824660)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2824661,0,"60f3ee3e365512571665fdfec50bd3b1c8f2d4e4fb747a610b4a9b6e83aea870")
setManifestid(2824661,"2863671636106140215")