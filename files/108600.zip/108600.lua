-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(108600)
setManifestid(228983,"8124929965194586177")
setManifestid(228984,"2547553897526095397")
setManifestid(228985,"3966345552745568756")
setManifestid(228986,"8782296191957114623")
setManifestid(228987,"4302102680580581867")
addappid(108602,0,"2c6834d3d5c0e48329883a18abe5614aa868c3e7911fc582c613cec21b3a5d1c")
setManifestid(108602,"2540194756181522692")
addappid(108603,0,"0b2a31059fa239993389b69ca9a0bebd9e3cbc8ccb446335c2becbe85060b0c4")
setManifestid(108603,"1153657949707515857")
addappid(108604,0,"3f8e8c70818c5469711aeaefe50b4f280028b72dfd7f7a4c83b6bd747e4a382a")
setManifestid(108604,"6286577881064486829")