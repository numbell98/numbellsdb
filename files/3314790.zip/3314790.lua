-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(3314790)
addappid(3314791,0,"01f256d876a29ffa69ec7fefed5588393e85c3e5326497d7da92427e011759ff")
--setManifestid(3314791,"395851268127937841")