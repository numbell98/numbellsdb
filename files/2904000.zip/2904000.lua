-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(2904000)
addappid(2904001,0,"1cea3f47529b0e53e7add1f7e63dcdf14634adfde24faf952128ad1034ee90e8")
setManifestid(2904001,"4685018066388793986")
addappid(2904002,0,"de0044598316af4e08b7d4552491ebb9a7e3ad4e36d1705fc82b0510f1c01acc")
setManifestid(2904002,"4936270597990808662")