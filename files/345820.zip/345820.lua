-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(345820)
addappid(345821,0,"4dcea77b08e111e2805676ba6797b296bee452ce2d8c5f67f41e7a22448506ed")
setManifestid(345821,"1907636325678954502")