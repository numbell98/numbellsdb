-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(2404880)
addappid(2404881,0,"dd3322cbddd81741e4bd8f3d9d08fbe6ff172e3f5c36fec42e215f6661d3ea4f")
setManifestid(2404881,"1926513974005836397")