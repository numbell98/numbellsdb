-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(428690)
setManifestid(228990,"1829726630299308803")
addappid(428692,0,"203f5d73e5428d2b13075ecc3056ed38d11baf0d03d2edc4b46ca48a756882a1")
setManifestid(428692,"3681364654357512261")
addappid(428693,0,"4675d3db6afb9c4cd216e57abea57b77f0c3fffff283ba86de7c7b750c651e15")
setManifestid(428693,"7511813023340123427")
addappid(428691,0,"c2886d221f990c67c34644bff6ca0f1d10fecc5c6de3b179594ae071bcdb6504")
setManifestid(428691,"4312993050357782985")