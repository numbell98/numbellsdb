-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(374320)
addappid(228984)
setManifestid(228984,"2547553897526095397")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(374321,0,"1e1f904451f44a8549008ac8152430dc18288dd22c8edda058afa86b926a4162")
setManifestid(374321,"6652575487689169560")
addappid(374322,0,"2e8b33176e957bf7c6ed4ad3c34847d1eef1ee846e900e1b4a2b4fc3a51b6c09")
setManifestid(374322,"6130303443397132373")
addappid(455380,0,"ee1942ee70f7707eb40415a87cd933fedf4de04aeab6f69421e106ff4b8d3228")
setManifestid(455380,"398045694410355072")
addappid(506970,0,"2dc303f9e1fc1f45f385b5d262b3b481ed10f11d38e5ca44edf7096a4f280385")
setManifestid(506970,"2441039608905796121")
addappid(506971,0,"0ce07245c46df4c8b1c5d7bef627f59f34b9fde6ea903ec21ea879cf6d9c10d5")
setManifestid(506971,"266039425715139370")