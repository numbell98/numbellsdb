-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(3094480)
addappid(3094481,0,"b5dabaa79baf6a1f6bdff9aeaca6184e1aa3388cd1e0ecb510b28a75d5fe190e")
setManifestid(3094481,"4121645659681638269")
addappid(3976400,0,"764e0bf65b537fa0287fe9759b27b4d23462f7753b7ffb46a49180a17afb3add")
setManifestid(3976400,"7571873862997708976")