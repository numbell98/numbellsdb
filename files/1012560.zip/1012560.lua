-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(1012560)
addappid(1012562,0,"8689a68e4f882ca4b0be3657a07230bd669395891aa57e46789bdb298e2144fb")
setManifestid(1012562,"7193914150019857074")
addappid(1012563,0,"34f9f1c309cdafaf598bdcdc2bb8a1fe2c9f55a4bb773634f69c375a989c5379")
setManifestid(1012563,"2697991281359202224")