-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(1222140)
addappid(1222141,0,"d87af32872df297ec519d0e79b6e0afc327b09048c3414622606b54efc46f519")