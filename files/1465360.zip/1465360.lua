-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(1465360)
setManifestid(228989,"3514306556860204959")
addappid(1465361,0,"0dd93272d1d47d5943b93081730b61e39d20a49e42873ca743dcd30322161fb0")
setManifestid(1465361,"3518876189924674658")
addappid(1465362,0,"924ebaf5547a976d7080e139e3ce420ce10a76bdcd89d74fa74a98fb7312b7fc")
setManifestid(1465362,"8996226671340099453")