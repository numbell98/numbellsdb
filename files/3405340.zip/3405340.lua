-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(3405340)
addappid(3405342,0,"0fbab2971279bba685debbfa503e2da7e014fb5066cec822fcda80f9465e304e")
setManifestid(3405342,"4301663095342179654")