-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(1167630)
addappid(1167634, 1, "4e402173b44873473aa98965b7075111059716ebc005137bc93e3e645fe13027")
setManifestid(1167634, "2921763231420441897", 0)
addappid(2657050, 1, "74eef5a7cdbac71c450a5d63ef57f193af7d4f1fd9717a88ece34eb6d9be7c3c")
setManifestid(2657050, "2321605783739972509", 0)
addappid(2657060, 1, "e0d5e7a570d792711265ff7532a2dc8bce4648837e8d86c94dcf77f531c09baf")
setManifestid(2657060, "7351540651308401980", 0)
addappid(2657080, 1, "204a8120beb5167f417969cac2724a24b5a1b35019dc45f94cca8fc986512185")
setManifestid(2657080, "1875220687609911643", 0)