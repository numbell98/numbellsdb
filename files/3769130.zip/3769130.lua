-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(3769130)
addappid(3769131,0,"79dda683e39e3551788e59192e005fe2d8b3e5f3f3adecacf712b638a9e732b3")
setManifestid(3769131,"8521580803762355549")
addappid(3769132,0,"4143d4c98337ddcbaa5a9c74444b143a9204495eca185108b268a76f237de3a6")
setManifestid(3769132,"145357012231529942")