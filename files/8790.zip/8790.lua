-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(8790)
addappid(8791,0,"a06cac07e45b67b68182034f069896536f6f5553aaa734500f7eca4d1a7120c6")
setManifestid(8791,"5098389729679155819")