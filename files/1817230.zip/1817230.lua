-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(1817230)
setManifestid(228988,"6645201662696499616")
setManifestid(228990,"1829726630299308803")
addappid(1817231,0,"0b72efdcb9381949af6d0260210821349bfd5047d33c3ed7e6a62e5fbbc9c816")
setManifestid(1817231,"2352550391294550783")
addappid(1817232,0,"1fd310294fa59e457d3df62891cb2a4b9285b3e6a7d97adad3bdbf70106d4e4f")
setManifestid(1817232,"2782758537428965591")