-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(30)
addappid(31, 1, "4d5feb3d2283c50f9d90f8d2b785f4ff4aa057829acf3fc00ce69326b14ca65a")
setManifestid(31, "3826716661969602728", 0)
addappid(32, 1, "8e2fcb16f1a7e99aec4c037da7536085d6342de4b87320cf723f1a7cf30af352")
setManifestid(32, "4900573185183522700", 0)
addappid(33, 1, "2863b8218868795c976bcda78604dd813861c9c8859fb751c71b38fd95c852e2")
setManifestid(33, "3999480029339495281", 0)
addappid(34, 1, "beca474197ac3935ab475f20ccb8c6813e15a99335dd419fc384881482b3926f")
setManifestid(34, "6589552847600003522", 0)
addappid(35, 1, "0a83a4119e657daa861fc0e3b4cb4229ea3cc346c5fdeeda090e69754bef9d20")
setManifestid(35, "783796907033752286", 0)