-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(3686930)
addappid(3686931,0,"c98412b675097a1beb19c035c8e852abe6b111fba17cb13470e740639da143e1")
