-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(3232040)
addappid(228989)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229005)
addappid(229007)
addappid(229020)
addappid(229033)
addappid(3232041,0,"da1d750063dc152ed92f546b7e0fa06d9adb3944c4fa4b8797697e6f8e637f2d")