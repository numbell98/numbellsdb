-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(1451190)
addappid(228988)
addappid(1451191,0,"543e5be37b6ba13500441680b3434302f89112d8f1fae261eec6e6cb245ffd22")
setManifestid(1451191,"8117537913339078501")