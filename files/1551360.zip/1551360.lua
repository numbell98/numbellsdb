-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(1551360)
addappid(1551361, 1, "13b42353469d4bb26905e2c12e73d4cd63ad89c21f438b3cf5b4b9a9bb659227")
setManifestid(1551361, "5207122455532745014", 0)
addappid(1613280, 1, "1cc274dec87bdc5651311f72c4c162f4067eafba2d8fb98cac6e3be307f5948a")
setManifestid(1613280, "1076978755699820847", 0)
addappid(1613281, 1, "d371f628205489a48d2888a29f596b335963d189f3e822ec32978292e989483a")
setManifestid(1613281, "8702078743692499086", 0)


addappid(1613282) -- Forza Horizon 5 Formula Drift Pack
addappid(1613283) -- Forza Horizon 5 VIP Membership
addappid(1613284) -- Forza Horizon 5 Welcome Pack
addappid(1613285) -- Forza Horizon 5 Treasure Map
addappid(1648020) -- Forza Horizon 5 Car Pass
addappid(1764060) -- Forza Horizon 5 2019 SUBARU STI S209
addappid(1764061) -- Forza Horizon 5 1967 Renault 8 Gordini
addappid(1764062) -- Forza Horizon 5 1970 Mercury Cyclone Spoiler
addappid(1764063) -- Forza Horizon 5 Premium VIP
addappid(1798680) -- Forza Horizon 5 Expansions Bundle
addappid(1812150) -- Forza Horizon 5 2017 Ferrari J50
addappid(1812151) -- Forza Horizon 5 2019 Ferrari Monza SP2
addappid(1812152) -- Forza Horizon 5 1979 Lamborghini Espada 400 GT
addappid(1812153) -- Forza Horizon 5 2020 Lamborghini Huracán EVO
addappid(1824140) -- Forza Horizon 5 1966 Jaguar XJ13
addappid(1824141) -- Forza Horizon 5 1993 Jaguar XJ220S
addappid(1824142) -- Forza Horizon 5 Ferrari 2018 FXX-K Evo
addappid(1824143) -- Forza Horizon 5 2018 Audi TT RS
addappid(1846790) -- Forza Horizon 5 2010 Porsche 911 SC
addappid(1846791) -- Forza Horizon 5 1992 Mazda 323 GT-R
addappid(1846792) -- Forza Horizon 5 2005 MG SV-R
addappid(1852790) -- Forza Horizon 5 2021 VW Golf R
addappid(1890180) -- Forza Horizon 5 1986 Ford Mustang SVO
addappid(1890181) -- Forza Horizon 5 2020 Toyota Tundra TRD
addappid(1890182) -- Forza Horizon 5 2006 Noble M400
addappid(1890183) -- Forza Horizon 5 2017 #25 Ferrari 488
addappid(1919260) -- Forza Horizon 5 1966 Toronado
addappid(1919261) -- Forza Horizon 5 2021 McLaren 620R
addappid(1919262) -- Forza Horizon 5 2021 MINI JCW GP
addappid(1919263) -- Forza Horizon 5 2019 Porsche 911 Speedster
addappid(1949470) -- Forza Horizon 5 2003 Ford Lightning
addappid(1949471) -- Forza Horizon 5 2014 SafariZ 370Z
addappid(1949472) -- Forza Horizon 5 2019 Toyota Tacoma
addappid(1949473) -- Forza Horizon 5 2008 Dodge Magnum
addappid(1949474) -- Forza Horizon 5 2020 BMW M8 Comp
addappid(1949475) -- Forza Horizon 5 2020 Audi RS 3
addappid(1949476) -- Forza Horizon 5 2018 Audi RS 5
addappid(1949477) -- Forza Horizon 5 1982 VW Pickup
addappid(2013600) -- Forza Horizon 5 2021 Aston Martin DBX
addappid(2013620) -- Forza Horizon 5 2020 Lexus RC F
addappid(2013621) -- Forza Horizon 5 2019 Nissan 370Z Nismo
addappid(2111240) -- Forza Horizon 5 D DLC
addappid(2440490) -- Horizon Racing Car Pack
addappid(2507010) -- Forza Horizon 5 Italian Exotics Car Pack
addappid(2614920) -- Forza Horizon 5 Super Speed Car Pack
addappid(2638820) -- Forza Horizon 5 American Automotive Car Pack
addappid(2676380) -- Forza Horizon 5 Fast X Car Pack
addappid(2738880) -- Forza Horizon 5 Chinese Lucky Stars Car Pack
addappid(2814020) -- Forza Horizon 5 European Automotive Car Pack
addappid(2868420) -- Forza Horizon 5 Acceleration Car Pack
addappid(2894270) -- Forza Horizon 5 Apex Allstars Car Pack
addappid(2997790) -- Forza Horizon 5 Universal Icons Car Pack
addappid(3051730) -- Forza Horizon 5 JDM Jewels Car Pack
addappid(3339980) -- Forza Horizon 5 Nissan Heritage Car Pack
