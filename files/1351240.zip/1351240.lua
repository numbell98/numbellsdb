-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(1351240)
setManifestid(228989,"3514306556860204959")
setManifestid(228990,"1829726630299308803")
addappid(1351241,0,"9e79fc452f59614517425d51bae47b42451e0a8aaba07aa8b48b756424d68539")
setManifestid(1351241,"6805473830722308430")