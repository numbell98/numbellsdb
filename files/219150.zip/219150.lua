-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(219150)
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229000)
setManifestid(229000,"4622705914179893434")
addappid(229020)
setManifestid(229020,"5799761707845834510")
addappid(219151,0,"456344fdb2b0b0fa153f9224614ea5f197a574c7fa01dca7d4e67396b90862f1")
setManifestid(219151,"2415600695765560507")
addappid(219153,0,"36914ef27763ac7dce257f1590b6e79691ca6a8344717af702f8561696084724")
setManifestid(219153,"1818962832386956036")
addappid(219154,0,"7b246edbccabec5571afe424f31a75091978a35a235dfd22f38202a1e560d6f0")
setManifestid(219154,"6950421988947666909")
addappid(219155,0,"5b5492d07dfd11304128730426b8c37825fb0e0704bcdd71c27b483e83245848")
setManifestid(219155,"741731804460681064")
addappid(275090)