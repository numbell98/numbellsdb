-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(2787320)
addappid(3482320)
addappid(3482330)
addappid(3482340)
addappid(2787321,0,"07fdf2268a8c0b6b8d7dd4c5d7978e054ce837759193f7f5cacd2968150199a7")
addtoken(3482320,"14061642696471356548")
addtoken(3482330,"3703994041447527511")
addtoken(3482340,"14440466782407368585")
setManifestid(2787321,"7083789523939365049")
addappid(3469320)
addappid(3469321,0,"0c96be9069d33e7760873c9f2e6662f01338c56034fac045763c19eb0e67b169")
addappid(3469322,0,"1f9af9be3000426f1cacc66ec197336fe9347b57ff5060d5030b52097d97dd0e")
addtoken(3469320,"3061271536733368647")
setManifestid(3469321,"2135996906142975274")
setManifestid(3469322,"8263642370269664531")
addappid(3482310)
addappid(3654280)