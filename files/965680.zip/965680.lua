-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(965680)
addappid(965681,0,"05685e2eda75d5459cd0ec3a1735e0eed68414c8fb3a56585c6c0938b3102f57")
setManifestid(965681,"1738001015534433881")