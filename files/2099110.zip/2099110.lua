-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(2099110)
addappid(2099111,0,"f72beb8416791f32f5214aeca544d8e2b30321b3310de239f9ae824182d2a5a7")
setManifestid(2099111,"5328832329044979460")