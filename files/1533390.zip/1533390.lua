-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(1533390)
addappid(1533391,0,"76a9af57a776f43d1f3210b9c3beb33607799ae510b2c235ba2964972bc6a945")
setManifestid(1533391,"2165851274764079687")