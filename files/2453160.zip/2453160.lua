-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(2453160)
addappid(2453161,0,"768d23554ddb00ac303ad9de2ebf64108fd846d8dfbc0a7b24cc911bf91914ab")
setManifestid(2453161,"134397666933108652")