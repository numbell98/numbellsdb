-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(2488620)
addappid(228989)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2488621,0,"631754f71ffa45dd53c6375d1e093a58315b5c7468e7dae0b1c1f168b1e3b062")
setManifestid(2488621,"8794508379538138073")
addappid(2488622,0,"3bb5b95c44afb22626dfe7f4717d1a8c829e93cf3bfad336352103c304cb4378")
setManifestid(2488622,"5100092380679030330")
addappid(2488623,0,"e2f55053a31b74536dc064d80009d8fb3905a66be6c1c4809a522f27166f609c")
setManifestid(2488623,"3598762856071715621")
addappid(2488624,0,"13515b2f09f7b81529a2c82c13692f6148e80f4aea11fde68100e35560e67a60")
setManifestid(2488624,"4688732099778701148")
addappid(2488625)
addappid(2488626)