-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(275850)
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228985)
addappid(228989)
addappid(275851,0,"a5ce5217e5d5d20115ea81209764d4e89f37bed55b84690951d5df23e73852a6")
setManifestid(275851,"8141833877123388948")
addappid(275852,0,"1f8fb10eb2401484d32af8e6c0d3b7e4148e78e4cf8f632afe1ab6600fb7e57d")
setManifestid(275852,"5745344797878468141")