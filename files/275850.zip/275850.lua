-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(275850)
setManifestid(228983,"8124929965194586177")
setManifestid(228985,"3966345552745568756")
setManifestid(228989,"3514306556860204959")
addappid(275851,0,"a5ce5217e5d5d20115ea81209764d4e89f37bed55b84690951d5df23e73852a6")
setManifestid(275851,"6929223266163140122")
addappid(275852,0,"1f8fb10eb2401484d32af8e6c0d3b7e4148e78e4cf8f632afe1ab6600fb7e57d")
setManifestid(275852,"4680125245167874701")