-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(274170)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(274172,0,"f948ce6d03348d1d575fafacccfca66afa47bd65418e34665d0b21ff85b5f00d")
setManifestid(274172,"7199041297203663559")
addappid(274173,0,"679aae395a3a5daa27d209ba716f1cedc31b9547c7220e45e83b5836659c516e")
setManifestid(274173,"1421157288583409625")
addappid(274174,0,"d1457cd83d22f30c48dfd29c06349b6485c37bea55a586477ae24e4586aba25f")
setManifestid(274174,"8626824437792969994")
addappid(274175,0,"466a79aa40bcdf719c80346e55dd7ed30cd4245fa47f82d5c5394affe5adc0ba")
setManifestid(274175,"4640517193330318629")
addappid(355390)