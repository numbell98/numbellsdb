-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(1059990)
addappid(1059991,0,"bd08c0c14575910ac0dddfe751ba2c4340b500b7d6c63249077d98c6ba132927")
setManifestid(1059991,"5611103566534941657")
addappid(1059992,0,"d85242e1d6806b83d9163ca8019e9d78c0f6e57dfac3fe06f666f32779960be8")
setManifestid(1059992,"6572661733325510626")
addappid(1059993,0,"b4885d039a0f2df90e2decd613498908c0e1f100f620504dd2542a955090fe33")
setManifestid(1059993,"2455369687063168689")