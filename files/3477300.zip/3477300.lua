-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(3477300)
addappid(3477301,0,"4d68ce9188c501ebc1df053a10c9bdf69f8912d30a218f65286981b081f80e58")
setManifestid(3477301,"4083205091650020074")
