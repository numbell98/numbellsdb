-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(2772750)
setManifestid(229020,"5799761707845834510")
addappid(2772751,0,"1ba0a188cd6a0fd66ff7664712ff982f4dbd0400ff82ebe3297a8d12a940be37")
setManifestid(2772751,"2999076502239140608")