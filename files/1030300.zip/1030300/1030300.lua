-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(1030300)
addappid(1030301, 1, "f4a253f96969f93b8a9392cddf6f1b779886ea10a160e7ca148b92bae09abd28")
setManifestid(1030301, "3229726349000518284", 0)
addappid(3928720)
