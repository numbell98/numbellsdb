-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(1372110)
addappid(1372111,0,"219ba7ad894442207719fbcc8f5108ead1e6a7990e9570faff49adedcb1a0673")