-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(1757300)
addappid(1757302,0,"477c69a9e90f67fcdc258a5d81db1350720e1320f906c219baf52338bef271cd")
setManifestid(1757302,"5195244742609329210")