-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(2375780)
addappid(2375781,0,"36327ca060d94c61bde1b0518cc17b2c9e035f7829155f0b90a846d24a27766c")
setManifestid(2375781,"8009826561121255847")