-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(2324290)
addappid(3340420)
addappid(3340430)
addappid(3810940)
addappid(2324291,0,"aa6abdfd89c3a5ab5bd39204a72f8eee90db311535794b1c01f5dfac9fe58998")
setManifestid(2324291,"4152056852592961544")