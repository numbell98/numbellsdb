-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(813230)
addappid(813231,0,"bb42c41063ff494ceca8a0ce69218fcc97cc5f31c2066992f80ec8dab229486e")
setManifestid(813231,"8951799273146338346")