-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(2553870)
addappid(2553871,0,"7eb6f1e8beddbfaeb434476e4d1d7c2a53c9c3b799888085d89703ee3e4ec36a")
setManifestid(2553871,"134942620736849302")
addappid(2553872,0,"afe6f6bc2bb24e9465165b6d86b8b674125673c0a0fbccac0d978b8ed742832f")
setManifestid(2553872,"3225395902680997725")
addappid(2553873,0,"4f7903e435bc33dca3742bbe6899391caf0b3d0b8021fadd90d6c077b0d34fd3")
setManifestid(2553873,"5853633659359000000")