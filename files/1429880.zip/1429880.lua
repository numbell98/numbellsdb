-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(1429880)
addappid(1429881, 1, "3faa97d2844a3dbe09fc697d4a781583446c83202f4ef4129091ba7c261426ff")
setManifestid(1429881, "7292073278369256550", 1202441108)