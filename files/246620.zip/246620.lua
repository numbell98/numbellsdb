-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(246620)
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(246621,0,"19ad23e511f566d12808b52a4cfabb6457d8acc91815acbaddc6fdfe76dacfbe")
setManifestid(246621,"1752000341490744572")
addappid(246622,0,"dd2e9f4b104c4ce27c22dadf3dd13210e54a51c0fa09f14addd72d8c05121f89")
setManifestid(246622,"2958597192848429529")
addappid(246623,0,"516e04bc485cebe525f9d28a727a2fbc29aad932656bcb36238448797d52a337")
setManifestid(246623,"3348516516908531559")
addappid(317520)
addappid(246624,0,"b7170469891310d1335cb12516164cff304a536657ad2c35fad0950719133123")
setManifestid(246624,"712597846969897429")
addappid(246625,0,"3c1666a26d525bf81d9b9c90bbd47b0fd637db2d2056950f5a9c8c72f76109bb")
setManifestid(246625,"8060770308095908779")
addappid(246626,0,"8d0fb3394cd06ae93b744373a1024f9a4c4b5c4a1e30ed95fadbb05718d02ff2")
setManifestid(246626,"1898025581291238622")