-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords


addappid(3527290, 1, "499eb049b24a30730d5926e9cf72bfa9237d1a7f6de06e94a05e9c2c01348478")
addappid(3527291, 1, "f55585bb6a00ba332421256f80ba05e27afc38fec6170b9a763138244c506f05")
setManifestid(3527291, "1604111082681813917", 0)
