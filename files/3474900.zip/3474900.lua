-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(3474900)
addappid(3474901,0,"fbc9891a1c20a2a57931cc7ac38cec562cf9fb996f284e99863b13fb98f140d8")
setManifestid(3474901,"6217757760363249104")
addappid(3474902)