-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(1607680)
addappid(1607681,0,"5b6701cae4899e4b3edbfb2983fae2f7a960736fc3b5172e8dfaa576a7116d8d")
setManifestid(1607681,"875560700777929151")
addappid(1607682,0,"f5d562748cbdf12c6813916a97fb60f91e0a1cbed6230067161472a6dfe1f681")
setManifestid(1607682,"7509719611536768421")