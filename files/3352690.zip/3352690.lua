-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(3352690)
addappid(3352691,0,"80574573245bdd639d7763b5942be1459adcead3eed6d24b2465c7564c99887c")
setManifestid(3352691,"8776416438632016850")