-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(1088710)
addappid(1088711,0,"c1b7e189e92f1444dccf6f8b7f8e0210e613a88b9d8de8c178044862d9c946f4")
addappid(1088712,0,"cca872cb599f2e4755fe421841cf97f37a1664954eb4f96f09edd06b956da99e")