-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(3180070)
addappid(3180071,0,"46e2cd1b157fec728146480948f03addd84b05ad244310eea46c81c3ebb47971")
setManifestid(3180071,"7011805513688058081")