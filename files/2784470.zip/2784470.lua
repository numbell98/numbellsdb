-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(2784470)
addappid(2784471,0,"3f1be54c32850828ed38015c593c4596fdec0af8820dc3e517efba88374d235e")
setManifestid(2784471,"5705085282799460968")