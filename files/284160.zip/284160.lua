-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(284160)
addappid(284161, 1, "0e77f1cd7bb3169d9885cc26c7d2ef9fffc02c8c49671bec7b7308dd6cf86229")
setManifestid(284161, "817589343590433926", 0)
