-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(1313140)
addappid(1313141,0,"e7826851aae21726cd847e809a97378d381ba16449186ce1cdb57c572d703460")
setManifestid(1313141,"612021980749543526")
addappid(1313142,0,"242e4da3afdadce6aa2329f9f1c8c71fe09c06f51a80c105a444734a12c9e3f2")
setManifestid(1313142,"1154357685179309926")