-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(493490)
setManifestid(228981,"7613356809904826842")
setManifestid(228982,"6413394087650432851")
setManifestid(228983,"8124929965194586177")
setManifestid(228984,"2547553897526095397")
setManifestid(228990,"1829726630299308803")
addappid(493491,0,"c4f4405ba8654ac03d7a74431206dc52bb2a92366d4573cbd39f79ca902cb68b")
setManifestid(493491,"4705343172144059293")
addappid(967230,0,"2c117136658608f75a3b2f1e578a87ee165e28456a29dd5afadf7b49ab35d3c2")
setManifestid(967230,"3769054687993125810")