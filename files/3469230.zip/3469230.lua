-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(3469230)
addappid(3469231,0,"e2a4e2e4e2879e971e987eca79da1590693452f4bea14ad18684310c8295ee89")
