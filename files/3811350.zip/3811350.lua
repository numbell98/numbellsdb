-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(3811350)
addappid(3837980)
addappid(3838000)
addappid(3838010)
addappid(3838020)
addappid(3811351,0,"db9426a87dfad02512eec2626bbe370106b1c71b9e3c137ea4a0609370f3111d")
setManifestid(3811351,"6099897891372466385")