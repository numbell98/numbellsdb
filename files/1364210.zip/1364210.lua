-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(1364210)
addappid(1364212,0,"e0d499227945f83fa2e9654ea918bc00d4e33990786e4eb6b16a3abefd1f2263")
setManifestid(1364212,"1857281912899643078")
addappid(1364211,0,"3748007409a9ce4382259fe6320aff7ea846f18eba5a9c4a9ec7bab1a6864761")
setManifestid(1364211,"8126239253086192449")