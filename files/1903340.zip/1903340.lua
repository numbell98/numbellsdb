-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(1903340)
addappid(1903341,1,"8593f9c4cd595f833d5344e55cd6c6fdb73d9a4fa05dab033ba71622265e8c82")
setManifestid(1903341,"2580035733812457425",45364385092)
addappid(3228520)
