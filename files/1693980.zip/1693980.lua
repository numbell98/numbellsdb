-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(1693980)
addappid(228989)
setManifestid(228989,"1332597174812030948")
addappid(1693981,0,"9738ac7c4b941978165b403d5785d6c8c331366f7feb30c0b276401fd71f4ccb")
setManifestid(1693981,"1038276949129655019")