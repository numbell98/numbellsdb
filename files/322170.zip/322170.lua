-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(322170)
addappid(322171, 1, "73d09cfe5a697e2e5bf2a2591259e00c715e9dc3376d4a71ff7e915483be399d")
setManifestid(322171, "7903404280228366327", 0)
addappid(322172, 1, "6accd00ac7da1a455e3e689eed217adcdcb14198e5dd23b1e553abbed6d5c38e")
setManifestid(322172, "6862317728889446455", 0)