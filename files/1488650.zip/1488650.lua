-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(1488650)
addappid(1488651,0,"aa26b0a1d4fef24747d5c63a176615868d5845d1761b7acdfca97e36d4ab6ad3")
setManifestid(1488651,"786805165804029478")