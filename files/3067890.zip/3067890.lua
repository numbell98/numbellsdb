-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(3067890) 
addappid(3067891, 1, "72a0b4eeae9db9d6be05f64f080e53e2a7a10f121635390a1997a4f3b9aba479")