-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(2193490)
addappid(228984)
setManifestid(228984,"2547553897526095397")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2193491,0,"d2a64f44381142fbdbd0a3d5d2b1535f9656eadbdced14c19c1ae048a153ae63")
setManifestid(2193491,"7984669434692252901")