-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(391540)
addappid(391541,0,"b416ce2b64256c530f83775eef790b171047ce48c3795077ebcfd83f9c627cab")
setManifestid(391541,"3413030246586915448")
addappid(391542,0,"6b3c4e270f515da237a568230e441e3a28a5984fa2a9224c31b6c3c825ca44fd")
setManifestid(391542,"1593483711954100372")
addappid(391543)
addappid(391544,0,"ba1155a879c71e2f624fe2fe74a0ac1baf68e199cc84e32e507c4c737299d92b")
setManifestid(391544,"5730345506996883260")