-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(256330)
addappid(256331,0,"316a6b1f639d6397f5f1a93e287d0a73d360ad1a793ac1dbc7d5135e0f4387c9")
setManifestid(256331,"6395107978861194687")