-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(2668510)
addappid(2668511, 1, "839eae6ac7edb75331c27732d207b339d78db2f2bd634989b08bd602a4c5983b")
setManifestid(2668511, "870294950404908569", 0)
addappid(2668512, 1, "ba1f0d8d7f0e02e8659bdd8d6a7738133974941d2da9845ae59a4f0fa456d801")
setManifestid(2668512, "4863697874015475084", 0)
