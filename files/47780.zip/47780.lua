-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(47780)
addappid(47781,0,"a1bf80735b83f9da3305093a3dc0300f3b489c3933fca7a8090416bd47bcba24")
setManifestid(47781,"6851344156015013660")
addappid(47782,0,"a860e916de1ee2ec96eb955f6396c661ed48ef7bd27014ed4cb4e1a828a0eb90")
setManifestid(47782,"3937982258830947080")
addappid(47783,0,"b731480fa88c5a5b63764dac1c8ebb252a3895753a8a5df7f2e9ea1349162ce7")
setManifestid(47783,"4338882721172215510")
addappid(47784,0,"5d01654cf5fdfd4f752e076865e11848530d5ecf9b7560e98706f5663a96b25f")
setManifestid(47784,"6812066011912063228")
addappid(47785,0,"9b354ed69366f4909c1c26117b806b2b0439aef2cdd5fc62707ca8760d6d23cc")
setManifestid(47785,"5382982879621903599")
addappid(47786,0,"08335766618a842c60538ca2a1753f67d4b482ff33cd4bf25e7f796a58f276db")
setManifestid(47786,"4659950238017740632")
addappid(47787,0,"9d7535157c9cd11ad25b7799e5c5515acc0d4940744cae1ce54862e2007d745b")
setManifestid(47787,"2671796994812695864")