-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(204371)

addappid(204372)

addappid(204360)

addappid(204361,0,"2428bf7adcf5bac5af5d4f346adeea328831349da1ac601a9d6c33db6d6b5677")

addtoken(204360,"14285758721387452983")

setManifestid(204361,"615242043503966810")