-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(3164500)
addappid(3164501,1,"81d0de07788de885787b0519b9dabf51618be6cba9124497decf572ac96624f4")
setManifestid(3164501, "5309396439327341981",7352849895)
