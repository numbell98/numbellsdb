-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(1281040) 
addappid(1281042, 1, "053c7e21b7936b8331deb11bbc9ae5a3b3c6df28b450220009cd8bfc91a5173b") -- Depot 1281042
