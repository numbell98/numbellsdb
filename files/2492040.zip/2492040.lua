-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(2492040)
addappid(3141970)
addappid(2492041,0,"22de4afa6bcad3761cbb58d3ba24b93045b264b33a9bf659ac64b3782375e691")
setManifestid(2492041,"5873254584822683634")