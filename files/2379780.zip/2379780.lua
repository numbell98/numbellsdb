-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(2379780)
addappid(228989)
addappid(2379781,0,"16261e41d3e864018778d4a1d81658521a67d9ffb8543ea7e3e21f0685721af1")
setManifestid(2379781,"3512319404653808464")
addappid(2379782,0,"d0d563bdb51d625d0ed3a3234be0282f8d9a25d81dce599cdcace7b88c3b4719")
setManifestid(2379782,"1898957422191678575")