-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(2450840)
addappid(2450841, 426132848, "4458b5c21ee0e65bbd9f3b9237025990e28f3de28fc011b222b20270303157e6")
setManifestid(2450841, "2039936296603849722")