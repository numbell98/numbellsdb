-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(2075070)
addappid(2075071,0,"add3aec9cb7617a6460aaafda50ed1df8a1529fe3b88cd858796ace96aaefce6")
setManifestid(2075071,"1248367819829409595")