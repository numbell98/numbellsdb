-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(2160220)
addappid(228989)
setManifestid(228989,"1332597174812030948")
addappid(228990)
setManifestid(228990,"5087715316087945828")
addappid(2160222,0,"93030989b69aab728a4f0f2ca3603f6baf6e194d193a607f730b93a4c4e9c855")
setManifestid(2160222,"5321151502539247118")