-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(2357910)
addappid(2357911,0,"57c05ae0ce63abf6588f641a1c36579e96e3191a194dbb98bd4c37555876f5d5")
setManifestid(2357911,"3457763883071404833")