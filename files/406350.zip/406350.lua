-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(406350)
setManifestid(228986,"8782296191957114623")
setManifestid(228990,"1829726630299308803")
addappid(406351,0,"1bea1168a0a4cf6c8c3079ad6cde520c8802342bd0a0e828a93ddc86eaf4b3a7")
setManifestid(406351,"278248430963401245")