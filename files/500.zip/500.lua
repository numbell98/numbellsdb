-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(500)
addappid(501, 1, "7a0b21eed084464fd2efb03ecc44116224b150f9377551ca7901ead966f21c26")
setManifestid(501, "1033288231699696627", 0)
addappid(502, 1, "54d51378fea25647cfe0c7d77804f29abd538c2606e4bf27b972d02816f34487")
setManifestid(502, "7950154663745719820", 0)
addappid(503, 1, "81d91ffef65bb0b38b50fe8ba06fe690aae9a0afd2c65c3bbc9ec55ba5a203c4")
setManifestid(503, "552987824516701103", 0)
addappid(504, 1, "f7671db1d3c622e18dd1245e2d3f173e8ea71ad425f82e37f5d4027a60416c1a")
setManifestid(504, "8212197441078172924", 0)
addappid(505, 1, "606977fdfcd55d1a781656ef5db7811bc9ab107d7604c68291a971aaa2a8c5b9")
setManifestid(505, "5045000053553889222", 0)
addappid(506, 1, "ff83a268db47060bbe676d22168de551715015faa70d962f3aa46368bb083bf8")
setManifestid(506, "3612476309264296188", 0)
addappid(507, 1, "d3a82b031014aa7c72b7c9ce029b2a15d8bfbcbb52ca29a56ac212f5bf1653db")
setManifestid(507, "3651932563014144986", 0)
addappid(508, 1, "1f37e4f4b59d43a25a36ab2b174899f36a063cd7a80b743604d71f1c7c61015c")
setManifestid(508, "3774429000353462406", 0)
addappid(515, 1, "f09a2fa191a845e1274cf6abb8e5bc7d6ffd6c04cb4a114ddf6a98f8967877e0")
setManifestid(515, "3278262610261574277", 0)