-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(17390)
addappid(17441,0,"d36bab5ea285050f33cb6ef2dcc79cad6b1f18e171159551761d207c31b1553d")
setManifestid(17441,"8696847549725547130")
addappid(17391,0,"c0e319f9c0a8603bdd501f50eade86c684467f3225d3920a9b82b30bcf81199b")
setManifestid(17391,"5845372279136212096")
addappid(355,0,"d9070f75486bdb862378a6fc49f9c5d97f33464827c0088a02a2b04954a05d6c")
setManifestid(355,"5583537944574530091")