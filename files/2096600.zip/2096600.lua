-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(2096600)
addappid(2096601,0,"1d418f319c368a25582ede887aacde5011e6b3489aa80c893346692a67c1e625")
setManifestid(2096601,"2149007021608283017")