-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(254700)
setManifestid(228983,"8124929965194586177")
setManifestid(228990,"1829726630299308803")
addappid(254701,0,"138bb1e5f555bb1881214eced9844b83b643695fc8726786a42b42a3f5c27902")
setManifestid(254701,"6999377187357974260")
addappid(272261,0,"e899c415aef8a533e80abb6c72b6bf3602f0b9b064c1bbb381a655667c576336")
setManifestid(272261,"4849919482799769104")
addappid(272260,0,"887fbc832b41f133430f20d78b365b07c724dd04c51ddcc48f879d907c4fd055")
setManifestid(272260,"8170509752846139490")
addappid(254704,0,"870c561ed9cbeb8f5733db64c240b45b609f1b8440890d999af03e206733d31d")
setManifestid(254704,"7927591321049438693")