-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(253840)
addappid(228984)
setManifestid(228984,"2547553897526095397")
addappid(228990)
setManifestid(228990,"5087715316087945828")
addappid(253841,0,"2b179febc3199ba5e83ba4dbf43d6d067b18a7ecb0d66a2d58fd1b378bace83a")
setManifestid(253841,"697900514062617528")