-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(2385530)
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(2385531,0,"891c9c194df2d680a3dbe94e736933f9252184a9680761d1cd6cef9fd178a77a")
setManifestid(2385531,"3349058867246333759")