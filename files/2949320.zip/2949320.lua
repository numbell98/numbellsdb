-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(2949320)
addappid(2949321,0,"3b33d27a923706d4e15053028684f05880816915c68004b0e4c9f341b711e664")
setManifestid(2949321,"1257345281144419644")