-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(2096610)
addappid(2096611,0,"7520613d714314319c640eaa259e33f95eea91f174c51525abd3ebd5c0698456")
setManifestid(2096611,"9150515189597169922")