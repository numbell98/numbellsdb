-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(638970)
addappid(638971,0,"ed70cc2d7c7ce6db4c6e3ccdd070786dcb37b73a0bc82825d89705311c39a100")
addappid(638972,0,"882baada465c2da02cf427b6e9744bb4a52e9980c6331beb97b60ad3af9fc0e0")
addappid(638973,0,"be3eaf318d15138653145447fa244e0838e0c25b21f9f0b797eb1660471c5a5e")
addappid(638975,0,"7d2df597ac4ddc5ea945aff1ca599b6c21c6604bbb1c070f208bf49244315461")