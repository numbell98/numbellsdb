-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addtoken(3592250,"16721295972219435974")
addtoken(3601500,"15312493784124965009")
addtoken(3601530,"7328380424935027833")
addappid(2486820)
addappid(2486821,0,"08e2539b55bc79fefa9447d3479c57b481c4256c12ebd50529fc3722fcc3727f")
addappid(3592250)
addappid(3601500)
addappid(3601530)
