-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(1191630)
addappid(228986)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1191631,0,"e198d4224f70aff84c4c83f267f507140ebc23db88219823abbf299053996dc5")
setManifestid(1191631,"6026232779144983899")