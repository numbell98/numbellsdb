-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(3293010)
addappid(3293011,0,"8e652df7f7f499154c4db62e26560d348c9528c9a516d8095f23c33eaf858b27")
setManifestid(3293011,"4137927488986261738")