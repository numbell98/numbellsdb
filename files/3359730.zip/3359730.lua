-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(3359730)
addappid(3359730,0,"0f11d40d2674cb19a055d6d65f4d4d845bec01167e0977aba91558bb93d4cad6")
setManifestid(3359730,"9216905361885018254")