-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(2007710)
addappid(2007714,0,"fedcdfe1e93067cefc1cec92abbcbd3505285d7f2276fe3c3b63a91ec3a097de")
setManifestid(2007714,"6923043240716021486")
addappid(2007713,0,"7a0aa3af848776e9cab0fd8a00caace9566b9bb5ad43e1a4e2723e958e71a88c")
setManifestid(2007713,"3943806785739698781")