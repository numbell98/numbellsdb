-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(3008130)
addappid(3592040)
addappid(3707620)
addappid(3707630)
addappid(3707640)
addappid(3008132,0,"6028aa5b91f9bf95194ec527c2ebdccd62e9a5df423e65ce32a73145aaa6c6b3")
addappid(3008133,0,"434623d389db7ee032958e856f56adcc7da748791f86963e54523321e2e57ee9")
addappid(3008134,0,"9c4e2acba05efb8e83b8b84191c8ea0454009ee00e7fc407eb32ad2c16cd5d9e")
addappid(3008135,0,"d47e689c1f7c949b76c2d74d998ef7cf4db0ebb66ef327e68a4e7e1b4bc931dd")
addappid(3008139,0,"9ca49a179625bb0a94c6cef85afa175dbf6f70f640eea01565cf29ee9b89b1a4")
addappid(3592041,0,"32f10ad2de76688dc0970aebede422b2921593489edc03e6e1e90d447aeb3890")
setManifestid(3008132,"4736842126314942335")
setManifestid(3008133,"1985368490837329254")
setManifestid(3008134,"7424448091867469272")
setManifestid(3008135,"5362655515814500238")
setManifestid(3008139,"8176716180096983026")
setManifestid(3592041,"505907278804388064")