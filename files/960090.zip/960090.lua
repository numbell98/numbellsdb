-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(960090)
addappid(960091,0,"fa0fa5bda5003ddb011da9f8fd27d1680b2128487a5b03b752ad0772e0f52cd9")
setManifestid(960091,"3691166422551729471")
addappid(960093,0,"dd1593b861e9bd1297c007a48bc6c5d6e2a6a8b3ba8808d76534e20afe5012d6")
setManifestid(960093,"5771197203084703089")