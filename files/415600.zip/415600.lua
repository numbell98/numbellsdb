-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(415600)
addappid(415601,0,"2efedb4253c033ce3fcfc067c74e3175b21e25d3f7ee4ad6f2cf6ad89736598f")
setManifestid(415601,"3039828881308813942")