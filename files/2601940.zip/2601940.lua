-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(2601940)
addappid(2601941,0,"abb367feaf3ec1d399531e980035a787956e55842fdc3bf1edde4bd385aacdfe")
setManifestid(2601941,"7304749755364813853")