-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(473690)
setManifestid(228986,"8782296191957114623")
setManifestid(228990,"1829726630299308803")
setManifestid(229005,"7992454656023763365")
addappid(473691,0,"3312a7c16cbea08e1ab0efce7eebada0c68a417edc76466f95d5b103f4d12e4f")
setManifestid(473691,"5990875066544786752")
addappid(681701,0,"35ed234bedd36ab001622e99af90b864103284ebaedceb8dcb1157c5e4456d4b")
setManifestid(681701,"34954983949673881")
addappid(473694,0,"e0ed94e1ed766df45ef0b17441f159950a9fac4e2a3c52f39403d60baad44d4b")
setManifestid(473694,"8442321928818718306")