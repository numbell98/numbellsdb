-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(1346840)
addappid(1346841,0,"97c6131497053c1bb5d67ba18ab299d620ed9102c349d33a39a88f631ffbea41")
setManifestid(1346841,"4785986818608701145")
addappid(1346842,0,"639e6998b8fd3c6504cc09f16dc96c068665e905632e4045daa48aae2f01c32c")
setManifestid(1346842,"8498148427209618157")