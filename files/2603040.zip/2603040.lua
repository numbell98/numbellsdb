-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(2603040)
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228984)
addappid(228988)
addappid(228989)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2603041,0,"454821620b726cdecaf413e240648c5b98644e910fa00e33d8c371c1f89c4ea1")
setManifestid(2603041,"4359002644277206484")