-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(1409530)
addappid(1409531,0,"8349a8c6273eb493d971830c427088fdeeae91a6b79a1cf6cdc727483cb7a429")
setManifestid(1409531,"4978835028129651661")